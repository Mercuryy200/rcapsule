console.log("Wardrobe Import extension loaded");
